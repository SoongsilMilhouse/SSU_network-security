#include <stddef.h>

int Packet_Handler(unsigned char *src, unsigned char **dst, int msgType, int *dst_len);

